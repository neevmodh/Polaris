# Polaris / Satellite Monitor

Analysis: Lake water-quality screening
Region: Loktak Lake
Baseline: 2020-02-03T04:31:29.371000Z
Comparison: 2024-03-08T04:31:31.806000Z

## Results

```json
{
  "analysis": "Lake water-quality screening",
  "method": "Pretrained U-Net water segmentation + SCL quality mask",
  "region": "Loktak Lake",
  "before_open_water_ha": 1008.63,
  "after_open_water_ha": 942.66,
  "common_water_ha": 703.17,
  "algae_proxy_increase_ha": 319.41,
  "observed_pair_pct": 93.0,
  "parameters": {
    "mndwi": 0.0,
    "algae_proxy_increase": 0.1
  },
  "indicators": [
    {
      "indicator": "NDCI",
      "meaning": "Red-edge algae proxy",
      "before_median": 0.030914952978491783,
      "after_median": 0.13365651667118073,
      "change": 0.10274156369268894,
      "units": "unitless spectral proxy"
    },
    {
      "indicator": "NDTI",
      "meaning": "Normalized turbidity proxy",
      "before_median": -0.12623435258865356,
      "after_median": -0.21906282007694244,
      "change": -0.09282846748828888,
      "units": "unitless spectral proxy"
    },
    {
      "indicator": "visible_turbidity_ratio",
      "meaning": "Visible-band turbidity ratio",
      "before_median": 2.147550582885742,
      "after_median": 1.9147124290466309,
      "change": -0.23283815383911133,
      "units": "unitless spectral proxy"
    }
  ],
  "interpretation": "Unitless indicators of optical change in clear open water; not measured chlorophyll, turbidity in NTU, pathogens, sewage, heavy metals or drinking-water safety. Field sampling and local calibration are required. Atmospheric correction, sun glint, shallow bottoms and floating vegetation can affect results. Shoreline pixels are eroded.",
  "comparison_support": "Same clear, open-water pixels at both dates; water areas include only observed eroded mask."
}
```

## Interpretation

Unitless indicators of optical change in clear open water; not measured chlorophyll, turbidity in NTU, pathogens, sewage, heavy metals or drinking-water safety. Field sampling and local calibration are required. Atmospheric correction, sun glint, shallow bottoms and floating vegetation can affect results. Shoreline pixels are eroded.

## Provenance

Before: S2A_T46REN_20200203T042429_L2A
After: S2B_T46REN_20240308T042959_L2A
CRS: EPSG:32646
Analysis pixel area: 900.0 m²

Refer to metadata.json for original image sources, scaling and processing details.